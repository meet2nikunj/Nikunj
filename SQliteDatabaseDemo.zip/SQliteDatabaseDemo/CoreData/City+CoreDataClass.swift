//
//  City+CoreDataClass.swift
//  
//
//  Created by Test App on 18/12/16.
//
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(City)
public class City: NSManagedObject {

}
