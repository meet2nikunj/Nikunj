//
//  State+CoreDataProperties.swift
//  
//
//  Created by Test App on 18/12/16.
//
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


extension State {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<State> {
        return NSFetchRequest<State>(entityName: "State");
    }

    @NSManaged public var statename: String?

}
