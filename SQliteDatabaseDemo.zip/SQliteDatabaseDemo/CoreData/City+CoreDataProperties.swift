//
//  City+CoreDataProperties.swift
//  
//
//  Created by Test App on 18/12/16.
//
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


extension City {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<City> {
        return NSFetchRequest<City>(entityName: "City");
    }

    @NSManaged public var cityname: String?
    @NSManaged public var state: NSSet?

}

// MARK: Generated accessors for state
extension City {

    @objc(addStateObject:)
    @NSManaged public func addToState(_ value: City)

    @objc(removeStateObject:)
    @NSManaged public func removeFromState(_ value: City)

    @objc(addState:)
    @NSManaged public func addToState(_ values: NSSet)

    @objc(removeState:)
    @NSManaged public func removeFromState(_ values: NSSet)

}
