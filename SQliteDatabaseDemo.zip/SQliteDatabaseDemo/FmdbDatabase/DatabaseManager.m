//
//  DatabaseManager.m
//  NikunjSqliteDemo
//
//  Created by agilemac-3 on 20/10/15.
//  Copyright © 2015 agilemac-3. All rights reserved.
//

#import "DatabaseManager.h"


@implementation DatabaseManager


+ (instancetype)sharedManager
{
    static id sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}

- (id)init
{
    self = [super init];
    if (self) {
        _databaseQueue = [[FMDatabaseQueue alloc] initWithPath:[self databasePath]];
    }
    return self;
}

- (NSString *)databasePath
{
    NSString *docsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    return [docsPath stringByAppendingPathComponent:@"Location.sqlite"];
}




@end
