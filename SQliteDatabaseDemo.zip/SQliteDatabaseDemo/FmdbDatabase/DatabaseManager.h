//
//  DatabaseManager.h
//  NikunjSqliteDemo
//
//  Created by agilemac-3 on 20/10/15.
//  Copyright © 2015 agilemac-3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabaseQueue.h"

@interface DatabaseManager : NSObject

@property (nonatomic, strong) FMDatabaseQueue *databaseQueue;

+ (instancetype)sharedManager;
- (NSString *)databasePath;

@end
