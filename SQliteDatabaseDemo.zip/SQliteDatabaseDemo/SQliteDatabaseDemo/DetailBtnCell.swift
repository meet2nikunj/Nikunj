//

import UIKit

class DetailBtnCell: UITableViewCell {

    @IBOutlet var imgIcon  : UIImageView!
    @IBOutlet var txtUser  : RATextfield!
    @IBOutlet var btnUser  : UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
