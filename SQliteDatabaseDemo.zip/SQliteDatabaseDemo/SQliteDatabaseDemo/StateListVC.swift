//
//
//
import UIKit

class StateListVC: UIViewController
{
    typealias onCompletion = (AnyObject!) -> Void // typealias for Complition block
    
    var completionHandlar: onCompletion = { _ in }
    
    var arrayStateData:[String] = []
    
    @IBOutlet var tblStateList : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        doInitialSettings()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Class Method
    func doInitialSettings()
    {
        self.showAnimate()
    }
    // Anitmation For Showing and removing popupview in view controller
    func showInView(_ completion: onCompletion!)-> Void
    {
        completionHandlar=completion
    }
    func showAnimate()
    {
        self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        self.view.alpha = 0.0;
        UIView.animate(withDuration: 0.25, animations:
        {
                self.view.alpha = 1.0
                self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        });
    }
    
    func removeAnimate()
    {
        UIView.animate(withDuration: 0.25, animations:
            {
                self.view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
                self.view.alpha = 0.0;
        }, completion:{(finished : Bool)  in
            if (finished)
            {
                self.view.removeFromSuperview()
            }
        });
    }
    
    // MARK: - Action Method
    @IBAction func backClicked(_ sender : AnyObject)
    {
        self.removeAnimate()
    }
    // MARK: - UITableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayStateData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAtIndexPath indexPath: IndexPath) -> UITableViewCell
    {
        let aCell  = tableView.dequeueReusableCell(withIdentifier: "StateCell", for: indexPath)
        aCell.textLabel!.text = "\(arrayStateData[indexPath.row])"
        return aCell
    }
    func tableView(_ tableView: UITableView, didSelectRowAtIndexPath indexPath: IndexPath)
    {
        completionHandlar(arrayStateData[indexPath.row] as AnyObject!)
        self.removeAnimate()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
