//
//  UserDetailCell.swift
//

//

import UIKit

class UserDetailCell: UITableViewCell,UITextFieldDelegate
{

    @IBOutlet var imgIcon  : UIImageView!
    @IBOutlet var txtUser  : RATextfield!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
