//
//  ViewController.swift
//  SQliteDatabaseDemo
//
//  Created by Test App on 11/12/16.
//  Copyright © 2016 Test App. All rights reserved.
//

import UIKit

struct AddStudentInfoConstants
{
    static let kName = "Name"
    static let kEmail = "Email"
    static let kBirthDate = "BirthDate"
    static let kPhoneNumber = "Phone Number"
    static let kState = "State"
    static let kCity = "City"
    
}
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate
{

    @IBOutlet var tblSignUp : UITableView!
    var dictAddSignUp = [String : String!]()
    var arrAddPlaceholder = [String]()

    var databaseManager : DatabaseManager!
    
    //MARK:- Life Cycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        initialSetting()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Class Method
    func initialSetting()
    {
    
        databaseManager = DatabaseManager.shared()

        arrAddPlaceholder = [AddStudentInfoConstants.kName,AddStudentInfoConstants.kEmail,AddStudentInfoConstants.kBirthDate,AddStudentInfoConstants.kPhoneNumber,AddStudentInfoConstants.kState,AddStudentInfoConstants.kCity]
        for strPlaceholder in arrAddPlaceholder
        {
            dictAddSignUp[strPlaceholder] = ""
        }
        
        tblSignUp.delegate=self
        tblSignUp.dataSource=self
        tblSignUp.reloadData()
    }
    
    
    // MARK: - Action Method
    
    @IBAction func registraionClicked(_ sender : AnyObject)
    {
        AppDelegate.getDelegate().showLoader()
        //AppDelegate.getDelegate().dismissLoader()
    }
    
    func btnStateClicked(_ sender:AnyObject)
    {
        var databasePath : String!
        let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let docsDir = dirPaths[0]
        databasePath = docsDir.appending("/Location.sqlite")
        let myDatabase = FMDatabase(path: databasePath as String)
        var arrayData:[String] = []
        let query_lab_test = "SELECT * FROM State"
        
        if myDatabase!.open()
        {
            let results_lab_test:FMResultSet? = myDatabase!.executeQuery(query_lab_test, withArgumentsIn: nil)
            while results_lab_test?.next() == true
            {
                if let resultString = results_lab_test?.string(forColumn: "stateName")
                {
                    arrayData.append(resultString)
                }
            }
            
            self.view.endEditing(true)
            print(arrayData)

            let stateRideList = self.storyboard!.instantiateViewController(withIdentifier: "StateListVC") as! StateListVC
            stateRideList.arrayStateData = arrayData
            self.addChildViewController(stateRideList)
            self.view.addSubview(stateRideList.view)
            self.didMove(toParentViewController: stateRideList)
            stateRideList.showInView({
                (state:AnyObject?) -> Void in
                print(String(describing: state!))
                
            })
            
        }
    }
    func btnCityClicked(_ sender:AnyObject)
    {
        var databasePath : String!
        let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let docsDir = dirPaths[0]
        databasePath = docsDir.appending("/Location.sqlite")
        let myDatabase = FMDatabase(path: databasePath as String)
        var arrayData:[String] = []
        let query_lab_test = "SELECT C.cityName FROM State S,City C Where S.stateId = C.stateId and S.stateName='Gujarat'"
        //let myDatabase = FMDatabase(path: databaseManager.databasePath() as String)
        
        if myDatabase!.open()
        {
            let results_lab_test:FMResultSet? = myDatabase!.executeQuery(query_lab_test, withArgumentsIn: nil)
            
            while results_lab_test?.next() == true
            {
                if let resultString = results_lab_test?.string(forColumn: "cityName")
                {
                    arrayData.append(resultString)
                }
            }
            print(arrayData)
        }

    }
    // MARK: - TableView Delegate And DateSource Method
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrAddPlaceholder.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let strTitle = arrAddPlaceholder[indexPath.row]
        
        if strTitle == AddStudentInfoConstants.kState
        {
            var aCell : DetailBtnCell!
            
            aCell = tableView.dequeueReusableCell(withIdentifier: "DetailBtnCell", for: indexPath as IndexPath) as! DetailBtnCell
            
            aCell.txtUser.placeholder = arrAddPlaceholder[indexPath.row]
            aCell.txtUser.text = dictAddSignUp[aCell.txtUser.placeholder!]
            aCell.txtUser.keyboardType = UIKeyboardType.default
            aCell.txtUser.isSecureTextEntry = false
            
            aCell.btnUser.addTarget(self, action:#selector(ViewController.btnStateClicked(_:)), for: UIControlEvents.touchUpInside)
            
            return aCell
        }
        else if strTitle == AddStudentInfoConstants.kCity
        {
            var aCell : DetailBtnCell!
            
            aCell = tableView.dequeueReusableCell(withIdentifier: "DetailBtnCell", for: indexPath as IndexPath) as! DetailBtnCell
            
            aCell.txtUser.placeholder = arrAddPlaceholder[indexPath.row]
            aCell.txtUser.text = dictAddSignUp[aCell.txtUser.placeholder!]
            
            aCell.txtUser.keyboardType = UIKeyboardType.default
            aCell.txtUser.isSecureTextEntry = false
            
             aCell.btnUser.addTarget(self, action:#selector(ViewController.btnCityClicked(_:)), for: UIControlEvents.touchUpInside)
            return aCell
        }

        else if strTitle == AddStudentInfoConstants.kBirthDate
        {
            var aCell : DetailBtnCell!
            
            aCell = tableView.dequeueReusableCell(withIdentifier: "DetailBtnCell", for: indexPath as IndexPath) as! DetailBtnCell
            
            aCell.txtUser.placeholder = arrAddPlaceholder[indexPath.row]
            aCell.txtUser.text = dictAddSignUp[aCell.txtUser.placeholder!]
            
            aCell.txtUser.keyboardType = UIKeyboardType.default
            aCell.txtUser.isSecureTextEntry = false
            
            //            aCell.btnUser.addTarget(self, action:#selector(RegistrationVC.btnDryCleaner(_:)), for: UIControlEvents.touchUpInside)
            return aCell
        }
        else
        {
            var aCell : UserDetailCell!
            
            aCell = tableView.dequeueReusableCell(withIdentifier: "UserDetailCell", for: indexPath as IndexPath) as! UserDetailCell
            
            aCell.txtUser.placeholder = arrAddPlaceholder[indexPath.row]
            aCell.txtUser.text = dictAddSignUp[aCell.txtUser.placeholder!]
            if strTitle == AddStudentInfoConstants.kName
            {
                aCell.txtUser.keyboardType = UIKeyboardType.default
                aCell.txtUser.autocapitalizationType = .words
                aCell.txtUser.isSecureTextEntry = false
                
            }
            else if strTitle == AddStudentInfoConstants.kEmail
            {
                aCell.txtUser.keyboardType = UIKeyboardType.emailAddress
                aCell.txtUser.autocapitalizationType = .words
                aCell.txtUser.isSecureTextEntry = false
            }
            else if strTitle == AddStudentInfoConstants.kPhoneNumber
            {
                aCell.txtUser.keyboardType = UIKeyboardType.phonePad
                aCell.txtUser.isSecureTextEntry = false
            }
            else if strTitle == AddStudentInfoConstants.kCity
            {
                aCell.txtUser.keyboardType = UIKeyboardType.default
                aCell.txtUser.isSecureTextEntry = false
            }
            else
            {
                aCell.txtUser.keyboardType = UIKeyboardType.default
                aCell.txtUser.isSecureTextEntry = false
            }
            return aCell
        }
        
    }
    

}

