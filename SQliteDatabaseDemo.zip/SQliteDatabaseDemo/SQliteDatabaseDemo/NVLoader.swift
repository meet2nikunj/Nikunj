
//

import UIKit
import NVActivityIndicatorView

class NVLoader: UIViewController,NVActivityIndicatorViewable {

    func showLoader(){
        
        let size = CGSize(width: 60, height:60)
        startAnimating(size, message: "", type: NVActivityIndicatorType(rawValue: 12)!, color: UIColor.white, padding: 0.0, displayTimeThreshold: nil, minimumDisplayTime: nil)
    }
    
    func dismissLoader(){
        
        stopAnimating()
        
        
    }
}
