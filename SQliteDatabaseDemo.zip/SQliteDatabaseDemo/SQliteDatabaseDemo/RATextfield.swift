//
//  RATextfield.swift
//
//  Created by SYS006 on 05/10/16.
//  Copyright © 2016 ImageInovation. All rights reserved.
//

import Foundation
import UIKit

@IBDesignable
class RATextfield: UITextField {
    
    var btnClear : UIButton!
    var btnRight : UIButton!
    var shadowLayer: CAShapeLayer!

    // MARK: - Properties
    
    @IBInspectable var boolShowClearButton : Bool = false
    {
        didSet
        {
            btnClear = UIButton(type: UIButtonType.custom)
            btnClear.setImage(UIImage(named: "clearTextIcon"), for: UIControlState())
            btnClear.frame = CGRect(x: 0, y: 0, width: 40, height: self.frame.size.height)
            btnClear.addTarget(self, action: #selector(RATextfield.clearText), for: UIControlEvents.touchUpInside)
            btnClear.alpha = 0.0
            rightView = self.btnClear
            rightViewMode = UITextFieldViewMode.whileEditing;
        }
    }
    
    func clearText()
    {
        btnClear.alpha = 0.0
        text = ""
    }

    @IBInspectable var borderColor : UIColor = UIColor.white
    {
        didSet
        {
            layer.borderColor = borderColor.cgColor
        }
    }
    
    @IBInspectable var borderWidth : CGFloat = 1.0
        {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable var cornerRadius : CGFloat = 1.0
        {
        didSet {
            layer.cornerRadius = cornerRadius
            clipsToBounds = true
        }
    }
    
    @IBInspectable var placeHolderColor : UIColor = UIColor.white {
        didSet {
            if ((placeholder) != nil) {
                attributedPlaceholder = NSAttributedString(string: placeholder!, attributes:[NSForegroundColorAttributeName: placeHolderColor])
            }
        }
    }
    
    @IBInspectable var leftViewImage : UIImage = UIImage() {
        didSet {
            let aView : UIView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: frame.size.height))
            let aImgView : UIImageView = UIImageView(image: leftViewImage)
            aImgView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            aImgView.center = CGPoint(x: aView.center.x, y: aView.center.y)
            aImgView.contentMode = UIViewContentMode.scaleAspectFit
            aView.addSubview(aImgView)
            leftViewMode = UITextFieldViewMode.always
            leftView = aView
        }
    }
    
    @IBInspectable var rightViewImage : UIImage = UIImage() {
        didSet {
            btnRight = UIButton(type: UIButtonType.custom)
            btnRight.setImage(rightViewImage, for: UIControlState())
            btnRight.frame = CGRect(x: 0, y: 0, width: 40, height: self.frame.size.height)
            //
            //            let aView : UIView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: frame.size.height))
            //            let aImgView : UIImageView = UIImageView(image: rightViewImage)
            //            aImgView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
            //            aImgView.center = CGPointMake(aView.center.x, aView.center.y)
            //            aImgView.contentMode = UIViewContentMode.ScaleAspectFit
            //            aView.addSubview(aImgView)
            rightViewMode = UITextFieldViewMode.always
            rightView = btnRight
        }
    }
    
    @IBInspectable var extraEmptyRight : Bool = false {
        didSet {
            addExtraEmptyRight()
        }
    }
    
    @IBInspectable var extraEmptyLeft : Bool = false {
        didSet {
            addExtraEmptyLeft()
        }
    }
    
    // MARK: - Initializers
    
    override init(frame : CGRect) {
        super.init(frame : frame)
        setup()
        configure()
    }
    
    convenience init() {
        self.init(frame:CGRect.zero)
        setup()
        configure()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
        configure()
        addEmptyView() // to add default space both side run time
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setup()
        configure()
    }
    
    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()
        setup()
        configure()
    }
    
    func setup() {
        layer.borderColor = UIColor.white.cgColor
        layer.borderWidth = 1.0
        layer.cornerRadius = 1.0
        
       /* layer.shadowOffset = CGSizeMake(5, 5)
        layer.shadowRadius = 0.0
        layer.shadowOpacity = 1.0
        layer.shadowColor = UIColor.blackColor().CGColor*/
        
    }
    
    func configure() {
        layer.borderColor = borderColor.cgColor
        layer.borderWidth = borderWidth
        layer.cornerRadius = cornerRadius
        
       /* layer.shadowOffset = CGSizeMake(5, 5)
        layer.shadowRadius = 0.0
        layer.shadowOpacity = 1.0
        layer.shadowColor = UIColor.blackColor().CGColor*/
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        /*if shadowLayer == nil {
            shadowLayer = CAShapeLayer()
            shadowLayer.path = UIBezierPath(roundedRect: bounds, cornerRadius: 20).CGPath
            shadowLayer.fillColor = UIColor.whiteColor().CGColor
            
            shadowLayer.shadowColor = UIColor.yellowColor().CGColor
            shadowLayer.shadowPath = shadowLayer.path
            shadowLayer.shadowOffset = CGSize(width: 2.0, height: 2.0)
            shadowLayer.shadowOpacity = 0.8
            shadowLayer.shadowRadius = 2
            
            layer.insertSublayer(shadowLayer, atIndex: 0)
            //layer.insertSublayer(shadowLayer, below: nil) // also works
        }*/
        
    }
    
    func addEmptyView() {
        let aLeftView : UIView = UIView(frame: CGRect(x: 0, y: 0, width: leftView == nil ? 10 : 40, height: frame.size.height))
        leftViewMode = UITextFieldViewMode.always
        leftView = aLeftView
        let aRightView : UIView = UIView(frame: CGRect(x: 0, y: 0, width: rightView == nil ? 10 : 40, height: frame.size.height))
        rightViewMode = UITextFieldViewMode.always
        rightView = aRightView
    }
    
    func addExtraEmptyLeft() {
        let aLeftView : UIView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: frame.size.height))
        leftViewMode = UITextFieldViewMode.always
        leftView = aLeftView
    }
    
    func addExtraEmptyRight() {
        let aRightView : UIView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: frame.size.height))
        rightViewMode = UITextFieldViewMode.always
        rightView = aRightView
    }
    
    /*
     // Only override drawRect: if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func drawRect(rect: CGRect) {
     // Drawing code
     }
     */
    
}
