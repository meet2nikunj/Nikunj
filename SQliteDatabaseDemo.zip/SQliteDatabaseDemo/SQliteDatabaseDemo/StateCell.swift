
//

import UIKit

class StateCell: UICollectionViewCell {
    
    @IBOutlet var btnState : UIButton!
    @IBOutlet var lblPost : UILabel!

    
}
